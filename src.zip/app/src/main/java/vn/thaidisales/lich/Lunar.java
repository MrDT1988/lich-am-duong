package vn.thaidisales.lich;

/** Lịch âm Việt Nam (thuật toán Hồ Ngọc Đức, múi giờ +7). */
public final class Lunar {
    private Lunar() {}
    private static final double TZ = 7.0;
    public static final String[] CAN = {"Giáp","Ất","Bính","Đinh","Mậu","Kỷ","Canh","Tân","Nhâm","Quý"};
    public static final String[] CHI = {"Tý","Sửu","Dần","Mão","Thìn","Tỵ","Ngọ","Mùi","Thân","Dậu","Tuất","Hợi"};

    /** {ngày âm, tháng âm, năm âm, nhuận(0/1), jd} */
    public static int[] fromSolar(int dd, int mm, int yy) {
        int dayNumber = jd(dd, mm, yy);
        int k = (int) Math.floor((dayNumber - 2415021.076998695) / 29.530588853);
        int monthStart = newMoon(k + 1);
        if (monthStart > dayNumber) monthStart = newMoon(k);
        int a11 = month11(yy), b11 = a11, lunarYear;
        if (a11 >= monthStart) { lunarYear = yy; a11 = month11(yy - 1); }
        else { lunarYear = yy + 1; b11 = month11(yy + 1); }
        int lunarDay = dayNumber - monthStart + 1;
        int diff = (int) Math.floor((monthStart - a11) / 29.0);
        int leap = 0, lunarMonth = diff + 11;
        if (b11 - a11 > 365) {
            int leapDiff = leapOffset(a11);
            if (diff >= leapDiff) { lunarMonth = diff + 10; if (diff == leapDiff) leap = 1; }
        }
        if (lunarMonth > 12) lunarMonth -= 12;
        if (lunarMonth >= 11 && diff < 4) lunarYear -= 1;
        return new int[]{lunarDay, lunarMonth, lunarYear, leap, dayNumber};
    }

    public static int jd(int dd, int mm, int yy) {
        int a = (14 - mm) / 12, y = yy + 4800 - a, m = mm + 12 * a - 3;
        int r = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
        if (r < 2299161) r = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083;
        return r;
    }

    private static int newMoon(int k) {
        double T = k / 1236.85, T2 = T * T, T3 = T2 * T, dr = Math.PI / 180;
        double jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
        jd1 += 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
        double M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
        double Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
        double F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
        double C1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr) + 0.0021 * Math.sin(2 * dr * M);
        C1 = C1 - 0.4068 * Math.sin(Mpr * dr) + 0.0161 * Math.sin(dr * 2 * Mpr);
        C1 = C1 - 0.0004 * Math.sin(dr * 3 * Mpr);
        C1 = C1 + 0.0104 * Math.sin(dr * 2 * F) - 0.0051 * Math.sin(dr * (M + Mpr));
        C1 = C1 - 0.0074 * Math.sin(dr * (M - Mpr)) + 0.0004 * Math.sin(dr * (2 * F + M));
        C1 = C1 - 0.0004 * Math.sin(dr * (2 * F - M)) - 0.0006 * Math.sin(dr * (2 * F + Mpr));
        C1 = C1 + 0.0010 * Math.sin(dr * (2 * F - Mpr)) + 0.0005 * Math.sin(dr * (2 * Mpr + M));
        double deltat = T < -11
                ? 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3
                : -0.000278 + 0.000265 * T + 0.000262 * T2;
        return (int) Math.floor(jd1 + C1 - deltat + 0.5 + TZ / 24);
    }

    private static int sunLong(int jdn) {
        double T = (jdn - 2451545.5 - TZ / 24) / 36525, T2 = T * T, dr = Math.PI / 180;
        double M = 357.52910 + 35999.05030 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
        double L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
        double DL = (1.914600 - 0.004817 * T - 0.000014 * T2) * Math.sin(dr * M);
        DL += (0.019993 - 0.000101 * T) * Math.sin(dr * 2 * M) + 0.000290 * Math.sin(dr * 3 * M);
        double L = (L0 + DL) * dr;
        L = L - Math.PI * 2 * Math.floor(L / (Math.PI * 2));
        return (int) Math.floor(L / Math.PI * 6);
    }

    private static int month11(int yy) {
        int off = jd(31, 12, yy) - 2415021;
        int k = (int) Math.floor(off / 29.530588853);
        int nm = newMoon(k);
        if (sunLong(nm) >= 9) nm = newMoon(k - 1);
        return nm;
    }

    private static int leapOffset(int a11) {
        int k = (int) Math.floor((a11 - 2415021.076998695) / 29.530588853 + 0.5);
        int last, i = 1, arc = sunLong(newMoon(k + i));
        do { last = arc; i++; arc = sunLong(newMoon(k + i)); } while (arc != last && i < 14);
        return i - 1;
    }

    public static String canChiNam(int y) { return CAN[(y + 6) % 10] + " " + CHI[(y + 8) % 12]; }
    public static String canChiThang(int m, int y) { return CAN[(y * 12 + m + 3) % 10] + " " + CHI[(m + 1) % 12]; }
    public static String canChiNgay(int jd) { return CAN[(jd + 9) % 10] + " " + CHI[(jd + 1) % 12]; }

    /** Giờ hoàng đạo theo chi của ngày. */
    public static String gioHoangDao(int jd) {
        String[] p = {"110100101100","001101001011","110011010010","101100110100","001011001101","010010110011"};
        String m = p[((jd + 1) % 12) % 6];
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 12; i++) if (m.charAt(i) == '1') {
            if (sb.length() > 0) sb.append(", ");
            int s = (i * 2 + 23) % 24;
            sb.append(CHI[i]).append(" (").append(s).append("-").append((s + 2) % 24).append("h)");
        }
        return sb.toString();
    }

    public static String ngayLe(int d, int m, int ld, int lm, int leap) {
        String s = null;
        switch (m * 100 + d) {
            case 101: s = "Tết Dương lịch"; break;
            case 214: s = "Lễ Tình nhân"; break;
            case 308: s = "Quốc tế Phụ nữ"; break;
            case 430: s = "Giải phóng miền Nam"; break;
            case 501: s = "Quốc tế Lao động"; break;
            case 601: s = "Quốc tế Thiếu nhi"; break;
            case 902: s = "Quốc khánh"; break;
            case 1020: s = "Phụ nữ Việt Nam"; break;
            case 1120: s = "Nhà giáo Việt Nam"; break;
            case 1224: s = "Giáng sinh"; break;
        }
        if (s != null || leap == 1) return s;
        switch (lm * 100 + ld) {
            case 101: case 102: case 103: return "Tết Nguyên Đán";
            case 115: return "Rằm tháng Giêng";
            case 310: return "Giỗ Tổ Hùng Vương";
            case 415: return "Phật Đản";
            case 505: return "Tết Đoan Ngọ";
            case 715: return "Vu Lan";
            case 815: return "Tết Trung Thu";
            case 1223: return "Ông Công Ông Táo";
        }
        return null;
    }
}
