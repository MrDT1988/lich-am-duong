package vn.thaidisales.lich;

import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import java.time.LocalDate;

/** 42 ô (6 tuần x 7 ngày, bắt đầu Thứ 2) cho một tháng dương — giao diện tối. */
public final class MonthModel {
    public static final int NEN = 0xFF161A20, NEN2 = 0xFF1C2128, XANH = 0xFF3DDC84, DO = 0xFFFF6B6B,
            DO_AM = 0xFFFF8A80, VANG = 0xFFFFC857, CHU = 0xFFE8EAED, CHU_DAM = 0xFFF1F3F5,
            XAM = 0xFF6B7280, XAM2 = 0xFF9AA3AE, MO = 0xFF3A3F47;
    public final LocalDate[] days = new LocalDate[42];
    public final int month, year;

    public MonthModel(int year, int month) {
        this.year = year; this.month = month;
        LocalDate first = LocalDate.of(year, month, 1);
        LocalDate start = first.minusDays(first.getDayOfWeek().getValue() - 1);
        for (int i = 0; i < 42; i++) days[i] = start.plusDays(i);
    }

    public static String amNgan(LocalDate d) {
        int[] l = Lunar.fromSolar(d.getDayOfMonth(), d.getMonthValue(), d.getYear());
        return "Âm " + l[0] + "/" + l[1] + (l[3] == 1 ? " nhuận" : "") + " · " + Lunar.canChiNam(l[2]);
    }

    /** Số dương to, số âm nhỏ bên dưới. T7/CN đỏ · lễ vàng · mùng 1/rằm: số âm đỏ. */
    public CharSequence cell(int i, boolean today) {
        LocalDate d = days[i];
        boolean trong = d.getMonthValue() == month;
        int[] l = Lunar.fromSolar(d.getDayOfMonth(), d.getMonthValue(), d.getYear());
        String le = Lunar.ngayLe(d.getDayOfMonth(), d.getMonthValue(), l[0], l[1], l[3]);
        boolean cuoiTuan = d.getDayOfWeek().getValue() >= 6;
        String duong = String.valueOf(d.getDayOfMonth());
        String am = (l[0] == 1) ? l[0] + "/" + l[1] + (l[3] == 1 ? "N" : "") : String.valueOf(l[0]);

        int c1 = !trong ? MO : cuoiTuan ? DO : le != null ? VANG : CHU;
        int c2 = !trong ? MO : (l[0] == 1 || l[0] == 15) ? DO_AM : XAM;
        if (today) { c1 = XANH; c2 = XANH; }

        SpannableStringBuilder sb = new SpannableStringBuilder(duong);
        sb.setSpan(new ForegroundColorSpan(c1), 0, duong.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new StyleSpan(Typeface.BOLD), 0, duong.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int s = sb.length();
        sb.append("\n").append(am);
        sb.setSpan(new ForegroundColorSpan(c2), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new RelativeSizeSpan(0.7f), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }
}
