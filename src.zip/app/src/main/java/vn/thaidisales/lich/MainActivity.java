package vn.thaidisales.lich;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String[] THU_DAI = {"Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"};
    private static final String[] THU = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
    private LocalDate chon = LocalDate.now(Store.VN), thang = chon.withDayOfMonth(1);
    private TextView tSo, tThu, tAm, tCanChi, tGio, tLe, tThang, tHopTieuDe;
    private LinearLayout luoi, dsHop;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0B0D11);
        getWindow().setNavigationBarColor(0xFF0B0D11);

        LinearLayout root = Ui.cot(this);
        root.setBackgroundColor(0xFF0B0D11);
        root.setPadding(px(16), px(16), px(16), px(28));

        // Thẻ ngày đang chọn
        LinearLayout the = Ui.cot(this);
        the.setBackground(Ui.bo(MonthModel.NEN, 22, this));
        the.setPadding(px(16), px(16), px(16), px(16));
        tThu = Ui.tv(this, 14, MonthModel.XAM2, false);
        tSo = Ui.tv(this, 64, MonthModel.CHU_DAM, true);
        tAm = Ui.tv(this, 17, MonthModel.XANH, true);
        tCanChi = Ui.tv(this, 13, MonthModel.XAM2, false);
        tGio = Ui.tv(this, 12, MonthModel.XAM, false);
        tLe = Ui.tv(this, 14, MonthModel.VANG, true);
        for (TextView t : new TextView[]{tThu, tSo, tAm, tCanChi, tGio, tLe}) { t.setGravity(Gravity.CENTER); the.addView(t); }
        root.addView(the);

        // Chuyển tháng
        LinearLayout nav = Ui.hang(this);
        nav.setPadding(px(4), px(16), 0, px(8));
        tThang = Ui.tv(this, 18, MonthModel.CHU_DAM, true);
        nav.addView(tThang, new LinearLayout.LayoutParams(0, -2, 1));
        TextView truoc = tron("‹"), sau = tron("›"), homNay = Ui.nut(this, "Hôm nay", false);
        homNay.setMinHeight(px(36));
        nav.addView(homNay);
        nav.addView(truoc);
        nav.addView(sau);
        truoc.setOnClickListener(v -> { thang = thang.minusMonths(1); veLuoi(); });
        sau.setOnClickListener(v -> { thang = thang.plusMonths(1); veLuoi(); });
        homNay.setOnClickListener(v -> { chon = LocalDate.now(Store.VN); thang = chon.withDayOfMonth(1); veHet(); });
        root.addView(nav);

        LinearLayout khung = Ui.cot(this);
        khung.setBackground(Ui.bo(MonthModel.NEN, 22, this));
        khung.setPadding(px(6), px(10), px(6), px(10));
        LinearLayout hThu = Ui.hang(this);
        for (String t : THU) {
            TextView x = Ui.tv(this, 11, t.equals("T7") || t.equals("CN") ? MonthModel.DO : MonthModel.XAM, true);
            x.setText(t);
            x.setGravity(Gravity.CENTER);
            hThu.addView(x, new LinearLayout.LayoutParams(0, -2, 1));
        }
        khung.addView(hThu);
        luoi = Ui.cot(this);
        khung.addView(luoi);
        root.addView(khung);

        // Lịch họp của ngày chọn
        LinearLayout hHop = Ui.hang(this);
        hHop.setPadding(px(4), px(18), 0, px(8));
        tHopTieuDe = Ui.tv(this, 16, MonthModel.CHU_DAM, true);
        hHop.addView(tHopTieuDe, new LinearLayout.LayoutParams(0, -2, 1));
        TextView them = Ui.nut(this, "+ Thêm", true);
        them.setMinHeight(px(36));
        them.setOnClickListener(v -> startActivity(new Intent(this, HopActivity.class).putExtra(HopActivity.NGAY, chon.toString())));
        hHop.addView(them);
        root.addView(hHop);
        dsHop = Ui.cot(this);
        root.addView(dsHop);

        TextView caiDat = Ui.nut(this, "Cài đặt widget (múi giờ / thời tiết)", false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = px(20);
        caiDat.setOnClickListener(v -> startActivity(new Intent(this, CaiDatActivity.class)));
        root.addView(caiDat, lp);

        TextView goiY = Ui.tv(this, 12, MonthModel.XAM, false);
        goiY.setText("Thêm widget: giữ lâu màn hình chính → Widget → Lịch Âm Dương (5×6).");
        goiY.setPadding(px(4), px(14), px(4), 0);
        root.addView(goiY);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0B0D11);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        veHet();
        LichWidget.lamMoi(this);
    }

    private void veHet() { veThe(); veLuoi(); veHop(); }

    private void veThe() {
        int[] l = Lunar.fromSolar(chon.getDayOfMonth(), chon.getMonthValue(), chon.getYear());
        tThu.setText(THU_DAI[chon.getDayOfWeek().getValue() - 1] + ", tháng " + chon.getMonthValue() + "/" + chon.getYear());
        tSo.setText(String.valueOf(chon.getDayOfMonth()));
        tAm.setText("Âm lịch: " + l[0] + " tháng " + l[1] + (l[3] == 1 ? " (nhuận)" : "") + " năm " + Lunar.canChiNam(l[2]));
        tCanChi.setText("Ngày " + Lunar.canChiNgay(l[4]) + " · Tháng " + Lunar.canChiThang(l[1], l[2]));
        tGio.setText("Giờ hoàng đạo: " + Lunar.gioHoangDao(l[4]));
        String le = Lunar.ngayLe(chon.getDayOfMonth(), chon.getMonthValue(), l[0], l[1], l[3]);
        if (le == null && l[0] == 1) le = "Mùng 1";
        if (le == null && l[0] == 15) le = "Ngày Rằm";
        tLe.setText(le == null ? "" : "★ " + le);
        tLe.setVisibility(le == null ? View.GONE : View.VISIBLE);
    }

    private void veLuoi() {
        MonthModel mm = new MonthModel(thang.getYear(), thang.getMonthValue());
        tThang.setText("Tháng " + mm.month + "  " + mm.year);
        luoi.removeAllViews();
        LocalDate homNay = LocalDate.now(Store.VN);
        Set<LocalDate> coHop = Store.ngayCoHop(this);
        for (int r = 0; r < 6; r++) {
            LinearLayout h = Ui.hang(this);
            for (int c = 0; c < 7; c++) {
                int i = r * 7 + c;
                LocalDate d = mm.days[i];
                FrameLayout o = new FrameLayout(this);
                TextView t = Ui.tv(this, 16, MonthModel.CHU, false);
                t.setGravity(Gravity.CENTER);
                t.setText(mm.cell(i, d.equals(homNay)));
                if (d.equals(homNay)) t.setBackgroundResource(R.drawable.bg_today);
                else if (d.equals(chon)) t.setBackground(Ui.bo(MonthModel.NEN2, 10, this));
                o.addView(t, new FrameLayout.LayoutParams(-1, -1));
                if (d.getMonthValue() == mm.month && coHop.contains(d)) {
                    View cham = new View(this);
                    GradientDrawable g = new GradientDrawable();
                    g.setShape(GradientDrawable.OVAL);
                    g.setColor(MonthModel.XANH);
                    cham.setBackground(g);
                    FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(px(5), px(5), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
                    fp.bottomMargin = px(3);
                    o.addView(cham, fp);
                }
                o.setOnClickListener(v -> {
                    chon = d;
                    if (d.getMonthValue() != thang.getMonthValue()) thang = d.withDayOfMonth(1);
                    veHet();
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, px(52), 1);
                lp.setMargins(px(1), px(1), px(1), px(1));
                h.addView(o, lp);
            }
            luoi.addView(h);
        }
    }

    private void veHop() {
        tHopTieuDe.setText("Lịch họp " + chon.getDayOfMonth() + "/" + chon.getMonthValue());
        dsHop.removeAllViews();
        List<Store.Hop> ds = Store.trongNgay(this, chon);
        if (ds.isEmpty()) {
            TextView t = Ui.tv(this, 13, MonthModel.XAM, false);
            t.setText("Chưa có lịch họp ngày này.");
            t.setPadding(px(4), px(4), 0, 0);
            dsHop.addView(t);
            return;
        }
        for (Store.Hop h : ds) {
            LinearLayout d = Ui.hang(this);
            d.setBackground(Ui.bo(MonthModel.NEN2, 14, this));
            d.setPadding(px(14), px(10), px(14), px(10));
            LocalDateTime g = h.gio();
            TextView gio = Ui.tv(this, 14, h.xong ? MonthModel.XAM : MonthModel.XANH, true);
            gio.setText(String.format("%02d:%02d", g.getHour(), g.getMinute()));
            d.addView(gio, new LinearLayout.LayoutParams(px(56), -2));
            LinearLayout c = Ui.cot(this);
            TextView t1 = Ui.tv(this, 14, h.xong ? MonthModel.XAM : MonthModel.CHU_DAM, false);
            t1.setText(h.ten + (h.xong ? " · đã xong" : ""));
            TextView t2 = Ui.tv(this, 12, MonthModel.XAM2, false);
            t2.setText(h.noi);
            c.addView(t1);
            if (!h.noi.isEmpty()) c.addView(t2);
            d.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
            d.setOnClickListener(v -> startActivity(new Intent(this, HopActivity.class).putExtra(HopActivity.ID, h.id)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = px(6);
            dsHop.addView(d, lp);
        }
    }

    private TextView tron(String s) {
        TextView t = Ui.tv(this, 18, MonthModel.CHU, false);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFF20252C);
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(36), px(36));
        lp.setMarginStart(px(8));
        t.setLayoutParams(lp);
        return t;
    }

    private int px(float v) { return Ui.px(this, v); }
}
