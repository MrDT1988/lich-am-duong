package vn.thaidisales.lich;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/** Thêm / sửa / đánh dấu xong một lịch họp. */
public class HopActivity extends Activity {
    public static final String ID = "id", VIEC = "viec", NGAY = "ngay";
    private static final String[] THU = {"Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"};
    private Store.Hop h;
    private LocalDate ngay;
    private LocalTime gio;
    private TextView tNgay, tGio;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        long id = getIntent().getLongExtra(ID, 0);
        String viec = getIntent().getStringExtra(VIEC);

        if ("xong".equals(viec)) {
            Store.Hop x = Store.tim(this, id);
            if (x != null) { x.xong = true; Store.luu(this, x); Toast.makeText(this, "Đã xong: " + x.ten, Toast.LENGTH_SHORT).show(); }
            LichWidget.lamMoi(this);
            finish();
            return;
        }

        h = id != 0 ? Store.tim(this, id) : null;
        if (h == null) {
            h = new Store.Hop();
            h.id = System.currentTimeMillis();
            h.ten = ""; h.noi = "";
            String n = getIntent().getStringExtra(NGAY);
            ngay = n != null ? LocalDate.parse(n) : LocalDate.now(Store.VN);
            gio = LocalTime.of(8, 0);
        } else {
            ngay = h.gio().toLocalDate();
            gio = h.gio().toLocalTime();
        }
        boolean moi = Store.tim(this, h.id) == null;
        getWindow().setStatusBarColor(0xFF0B0D11);
        getWindow().setNavigationBarColor(0xFF0B0D11);

        LinearLayout root = Ui.cot(this);
        root.setBackgroundColor(0xFF0B0D11);
        root.setPadding(Ui.px(this, 18), Ui.px(this, 20), Ui.px(this, 18), Ui.px(this, 24));

        TextView tieuDe = Ui.tv(this, 20, MonthModel.CHU_DAM, true);
        tieuDe.setText(moi ? "Thêm lịch họp" : "Sửa lịch họp");
        root.addView(tieuDe);

        root.addView(Ui.muc(this, "TÊN CUỘC HỌP"));
        EditText eTen = Ui.o(this, "Ví dụ: Họp giao ban Sale");
        eTen.setText(h.ten);
        root.addView(eTen);

        root.addView(Ui.muc(this, "ĐỊA ĐIỂM"));
        EditText eNoi = Ui.o(this, "Ví dụ: Văn phòng / Zoom");
        eNoi.setText(h.noi);
        root.addView(eNoi);

        root.addView(Ui.muc(this, "NGÀY VÀ GIỜ (GIỜ VIỆT NAM)"));
        LinearLayout hang = Ui.hang(this);
        tNgay = Ui.nut(this, "", false);
        tGio = Ui.nut(this, "", false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        hang.addView(tNgay, new LinearLayout.LayoutParams(0, -2, 2));
        lp.setMarginStart(Ui.px(this, 8));
        hang.addView(tGio, lp);
        root.addView(hang);
        veNgayGio();
        tNgay.setOnClickListener(v -> new DatePickerDialog(this, (dp, y, m, d) -> { ngay = LocalDate.of(y, m + 1, d); veNgayGio(); },
                ngay.getYear(), ngay.getMonthValue() - 1, ngay.getDayOfMonth()).show());
        tGio.setOnClickListener(v -> new TimePickerDialog(this, (tp, hh, mm) -> { gio = LocalTime.of(hh, mm); veNgayGio(); },
                gio.getHour(), gio.getMinute(), true).show());

        LinearLayout nut = Ui.hang(this);
        nut.setPadding(0, Ui.px(this, 28), 0, 0);
        nut.setGravity(Gravity.END);
        if (!moi) {
            TextView xoa = Ui.nut(this, "Xoá", false);
            xoa.setTextColor(MonthModel.DO);
            xoa.setOnClickListener(v -> { Store.xoa(this, h.id); LichWidget.lamMoi(this); finish(); });
            nut.addView(xoa);
            TextView xong = Ui.nut(this, h.xong ? "Mở lại" : "Đã xong", false);
            xong.setOnClickListener(v -> { h.xong = !h.xong; Store.luu(this, h); LichWidget.lamMoi(this); finish(); });
            LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(-2, -2);
            l2.setMarginStart(Ui.px(this, 8));
            nut.addView(xong, l2);
        }
        TextView luu = Ui.nut(this, "Lưu", true);
        luu.setOnClickListener(v -> {
            h.ten = eTen.getText().toString().trim();
            h.noi = eNoi.getText().toString().trim();
            if (h.ten.isEmpty()) { eTen.setError("Nhập tên cuộc họp"); return; }
            h.luc = LocalDateTime.of(ngay, gio).atZone(Store.VN).toInstant().toEpochMilli();
            Store.luu(this, h);
            LichWidget.lamMoi(this);
            finish();
        });
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(-2, -2);
        l3.setMarginStart(Ui.px(this, 8));
        nut.addView(luu, l3);
        root.addView(nut);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0B0D11);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
    }

    private void veNgayGio() {
        int[] l = Lunar.fromSolar(ngay.getDayOfMonth(), ngay.getMonthValue(), ngay.getYear());
        tNgay.setText(THU[ngay.getDayOfWeek().getValue() - 1] + ", " + ngay.getDayOfMonth() + "/" + ngay.getMonthValue()
                + " · âm " + l[0] + "/" + l[1]);
        tGio.setText(String.format("%02d:%02d", gio.getHour(), gio.getMinute()));
    }
}
