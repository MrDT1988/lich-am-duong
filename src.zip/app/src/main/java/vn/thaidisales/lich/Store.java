package vn.thaidisales.lich;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Lưu cài đặt, lịch họp, thời tiết. */
public final class Store {
    private Store() {}
    public static final ZoneId VN = ZoneId.of("Asia/Ho_Chi_Minh");

    // ---- Múi giờ có sẵn: tên nước, thành phố, zone id
    public static final String[][] TZ = {
            {"Trung Quốc", "Bắc Kinh", "Asia/Shanghai"},
            {"Hồng Kông", "Hồng Kông", "Asia/Hong_Kong"},
            {"Đài Loan", "Đài Bắc", "Asia/Taipei"},
            {"Hàn Quốc", "Seoul", "Asia/Seoul"},
            {"Nhật Bản", "Tokyo", "Asia/Tokyo"},
            {"Thái Lan", "Bangkok", "Asia/Bangkok"},
            {"Singapore", "Singapore", "Asia/Singapore"},
            {"Malaysia", "Kuala Lumpur", "Asia/Kuala_Lumpur"},
            {"Ấn Độ", "New Delhi", "Asia/Kolkata"},
            {"UAE", "Dubai", "Asia/Dubai"},
            {"Anh", "London", "Europe/London"},
            {"Pháp", "Paris", "Europe/Paris"},
            {"Đức", "Berlin", "Europe/Berlin"},
            {"Mỹ (bờ Đông)", "New York", "America/New_York"},
            {"Mỹ (bờ Tây)", "Los Angeles", "America/Los_Angeles"},
            {"Úc", "Sydney", "Australia/Sydney"},
    };

    // ---- Vị trí thời tiết: tên, vĩ độ, kinh độ
    public static final String[][] CITY = {
            {"Mỹ Tho", "10.3600", "106.3600"},
            {"Bến Tre", "10.2415", "106.3759"},
            {"TP. Hồ Chí Minh", "10.7769", "106.7009"},
            {"Cần Thơ", "10.0452", "105.7469"},
            {"Đà Nẵng", "16.0544", "108.2022"},
            {"Hà Nội", "21.0278", "105.8342"},
            {"Bắc Kinh", "39.9042", "116.4074"},
            {"Thượng Hải", "31.2304", "121.4737"},
            {"Quảng Châu", "23.1291", "113.2644"},
            {"Thâm Quyến", "22.5431", "114.0579"},
            {"Đông Quản", "23.0207", "113.7518"},
    };

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("lich", Context.MODE_PRIVATE); }

    public static boolean phaiLaThoiTiet(Context c) { return "weather".equals(sp(c).getString("mode", "tz")); }
    public static void datCheDo(Context c, boolean thoiTiet) { sp(c).edit().putString("mode", thoiTiet ? "weather" : "tz").apply(); }
    public static int tz(Context c) { return Math.min(sp(c).getInt("tz", 0), TZ.length - 1); }
    public static void datTz(Context c, int i) { sp(c).edit().putInt("tz", i).apply(); }
    public static int city(Context c) { return Math.min(sp(c).getInt("city", 0), CITY.length - 1); }
    public static void datCity(Context c, int i) { sp(c).edit().putInt("city", i).putLong("w_time", 0).apply(); }

    /** "nhanh hơn 1 giờ" / "chậm hơn 6 giờ" / "cùng giờ" */
    public static String chenh(String zone) {
        Instant now = Instant.now();
        int a = ZoneId.of(zone).getRules().getOffset(now).getTotalSeconds();
        int b = VN.getRules().getOffset(now).getTotalSeconds();
        int d = (a - b) / 60;
        if (d == 0) return "cùng giờ";
        int h = Math.abs(d) / 60, m = Math.abs(d) % 60;
        String s = h + " giờ" + (m > 0 ? " " + m + " phút" : "");
        return (d > 0 ? "nhanh hơn " : "chậm hơn ") + s;
    }

    // ---- Thời tiết (cache)
    public static void luuThoiTiet(Context c, int t, int hi, int lo, int code) {
        sp(c).edit().putInt("w_t", t).putInt("w_hi", hi).putInt("w_lo", lo).putInt("w_code", code)
                .putLong("w_time", System.currentTimeMillis()).apply();
    }
    public static long thoiTietLuc(Context c) { return sp(c).getLong("w_time", 0); }
    public static int[] thoiTiet(Context c) {
        SharedPreferences p = sp(c);
        return new int[]{p.getInt("w_t", 0), p.getInt("w_hi", 0), p.getInt("w_lo", 0), p.getInt("w_code", -1)};
    }
    public static String moTa(int code) {
        if (code < 0) return "Đang tải…";
        if (code == 0) return "Trời quang";
        if (code <= 2) return "Ít mây";
        if (code == 3) return "Nhiều mây";
        if (code <= 48) return "Sương mù";
        if (code <= 57) return "Mưa phùn";
        if (code <= 67) return "Có mưa";
        if (code <= 77) return "Có tuyết";
        if (code <= 82) return "Mưa rào";
        if (code <= 86) return "Tuyết rơi";
        return "Dông";
    }

    // ---- Lịch họp
    public static final class Hop {
        public long id, luc; public String ten, noi; public boolean xong;
        public LocalDateTime gio() { return LocalDateTime.ofInstant(Instant.ofEpochMilli(luc), VN); }
    }

    public static List<Hop> dsHop(Context c) {
        List<Hop> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("hop", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Hop h = new Hop();
                h.id = o.getLong("id"); h.luc = o.getLong("luc");
                h.ten = o.optString("ten"); h.noi = o.optString("noi"); h.xong = o.optBoolean("xong");
                r.add(h);
            }
        } catch (Exception ignored) {}
        Collections.sort(r, (x, y) -> Long.compare(x.luc, y.luc));
        return r;
    }

    static void ghi(Context c, List<Hop> ds) {
        JSONArray a = new JSONArray();
        try {
            for (Hop h : ds) {
                JSONObject o = new JSONObject();
                o.put("id", h.id); o.put("luc", h.luc); o.put("ten", h.ten); o.put("noi", h.noi); o.put("xong", h.xong);
                a.put(o);
            }
        } catch (Exception ignored) {}
        sp(c).edit().putString("hop", a.toString()).apply();
    }

    public static Hop tim(Context c, long id) {
        for (Hop h : dsHop(c)) if (h.id == id) return h;
        return null;
    }

    public static void luu(Context c, Hop h) {
        List<Hop> ds = dsHop(c);
        boolean co = false;
        for (int i = 0; i < ds.size(); i++) if (ds.get(i).id == h.id) { ds.set(i, h); co = true; }
        if (!co) ds.add(h);
        ghi(c, ds);
    }

    public static void xoa(Context c, long id) {
        List<Hop> ds = dsHop(c);
        ds.removeIf(h -> h.id == id);
        ghi(c, ds);
    }

    /** Các cuộc họp chưa xong, từ đầu hôm nay trở đi. */
    public static List<Hop> sapToi(Context c) {
        long tu = LocalDate.now(VN).atStartOfDay(VN).toInstant().toEpochMilli();
        List<Hop> r = new ArrayList<>();
        for (Hop h : dsHop(c)) if (!h.xong && h.luc >= tu) r.add(h);
        return r;
    }

    public static List<Hop> trongNgay(Context c, LocalDate d) {
        List<Hop> r = new ArrayList<>();
        for (Hop h : dsHop(c)) if (h.gio().toLocalDate().equals(d)) r.add(h);
        return r;
    }

    public static Set<LocalDate> ngayCoHop(Context c) {
        Set<LocalDate> s = new HashSet<>();
        for (Hop h : dsHop(c)) if (!h.xong) s.add(h.gio().toLocalDate());
        return s;
    }
}
