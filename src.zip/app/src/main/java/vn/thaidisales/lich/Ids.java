package vn.thaidisales.lich;

final class Ids {
    static final int[] O = {R.id.o0,R.id.o1,R.id.o2,R.id.o3,R.id.o4,R.id.o5,R.id.o6,R.id.o7,R.id.o8,R.id.o9,R.id.o10,R.id.o11,R.id.o12,R.id.o13,R.id.o14,R.id.o15,R.id.o16,R.id.o17,R.id.o18,R.id.o19,R.id.o20,R.id.o21,R.id.o22,R.id.o23,R.id.o24,R.id.o25,R.id.o26,R.id.o27,R.id.o28,R.id.o29,R.id.o30,R.id.o31,R.id.o32,R.id.o33,R.id.o34,R.id.o35,R.id.o36,R.id.o37,R.id.o38,R.id.o39,R.id.o40,R.id.o41};
    static final int[] D = {R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6,R.id.d7,R.id.d8,R.id.d9,R.id.d10,R.id.d11,R.id.d12,R.id.d13,R.id.d14,R.id.d15,R.id.d16,R.id.d17,R.id.d18,R.id.d19,R.id.d20,R.id.d21,R.id.d22,R.id.d23,R.id.d24,R.id.d25,R.id.d26,R.id.d27,R.id.d28,R.id.d29,R.id.d30,R.id.d31,R.id.d32,R.id.d33,R.id.d34,R.id.d35,R.id.d36,R.id.d37,R.id.d38,R.id.d39,R.id.d40,R.id.d41};
}
