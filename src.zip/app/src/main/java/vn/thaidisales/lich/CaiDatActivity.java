package vn.thaidisales.lich;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Cài đặt widget: ô trái cố định giờ VN; ô phải chọn múi giờ nước khác hoặc thời tiết. */
public class CaiDatActivity extends Activity {
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0B0D11);
        getWindow().setNavigationBarColor(0xFF0B0D11);
        root = Ui.cot(this);
        root.setBackgroundColor(0xFF0B0D11);
        root.setPadding(Ui.px(this, 18), Ui.px(this, 20), Ui.px(this, 18), Ui.px(this, 24));
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0B0D11);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
        ve();
    }

    private void ve() {
        root.removeAllViews();
        TextView tieuDe = Ui.tv(this, 20, MonthModel.CHU_DAM, true);
        tieuDe.setText("Cài đặt widget");
        root.addView(tieuDe);

        root.addView(Ui.muc(this, "Ô BÊN TRÁI"));
        root.addView(the("Giờ Việt Nam", "Cố định · kèm ngày âm", null, false, false));

        boolean tt = Store.phaiLaThoiTiet(this);
        String[] z = Store.TZ[Store.tz(this)];
        root.addView(Ui.muc(this, "Ô BÊN PHẢI — CHỌN 1"));
        root.addView(the("Múi giờ nước khác", "Đang chọn: " + z[0] + " (" + z[1] + ")",
                () -> { Store.datCheDo(this, false); xong(); }, true, !tt));
        root.addView(khoang());
        root.addView(the("Thời tiết", "Nhiệt độ, cao/thấp tại " + Store.CITY[Store.city(this)][0],
                () -> { Store.datCheDo(this, true); Store.sp(this).edit().putLong("w_time", 0).apply(); xong(); }, true, tt));

        root.addView(Ui.muc(this, "MÚI GIỜ"));
        root.addView(dong("Nước / thành phố", z[0] + " · " + z[1], () -> {
            String[] ten = new String[Store.TZ.length];
            for (int i = 0; i < ten.length; i++) ten[i] = Store.TZ[i][0] + " — " + Store.TZ[i][1] + " (" + Store.chenh(Store.TZ[i][2]) + ")";
            new AlertDialog.Builder(this).setTitle("Chọn múi giờ")
                    .setSingleChoiceItems(ten, Store.tz(this), (d, i) -> { Store.datTz(this, i); d.dismiss(); xong(); }).show();
        }));
        root.addView(khoang());
        root.addView(dong("Chênh với Việt Nam", Store.chenh(z[2]), null));

        root.addView(Ui.muc(this, "THỜI TIẾT"));
        root.addView(dong("Vị trí", Store.CITY[Store.city(this)][0], () -> {
            String[] ten = new String[Store.CITY.length];
            for (int i = 0; i < ten.length; i++) ten[i] = Store.CITY[i][0];
            new AlertDialog.Builder(this).setTitle("Chọn vị trí")
                    .setSingleChoiceItems(ten, Store.city(this), (d, i) -> { Store.datCity(this, i); d.dismiss(); xong(); }).show();
        }));

        TextView ghiChu = Ui.tv(this, 12, MonthModel.XAM, false);
        ghiChu.setText("Thời tiết cập nhật khoảng 30 phút/lần, cần mạng. Múi giờ chạy không cần mạng.\nChạm ô bên phải trên widget để mở nhanh màn hình này.");
        ghiChu.setPadding(Ui.px(this, 4), Ui.px(this, 16), 0, 0);
        root.addView(ghiChu);
    }

    private void xong() {
        LichWidget.lamMoi(this);
        if (Store.phaiLaThoiTiet(this)) new Thread(() -> { LichWidget.taiThoiTiet(this); LichWidget.capNhat(this); }).start();
        ve();
    }

    private android.view.View khoang() {
        android.view.View v = new android.view.View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.px(this, 8)));
        return v;
    }

    private LinearLayout the(String ten, String phu, Runnable bam, boolean chon, boolean dangChon) {
        LinearLayout l = Ui.hang(this);
        l.setPadding(Ui.px(this, 14), Ui.px(this, 12), Ui.px(this, 14), Ui.px(this, 12));
        l.setBackground(Ui.bo(dangChon ? 0xFF1C2B23 : MonthModel.NEN2, 14, this));
        if (chon) {
            TextView o = Ui.tv(this, 18, dangChon ? MonthModel.XANH : 0xFF4B5260, true);
            o.setText(dangChon ? "◉" : "○");
            o.setPadding(0, 0, Ui.px(this, 12), 0);
            l.addView(o);
        }
        LinearLayout c = Ui.cot(this);
        TextView t1 = Ui.tv(this, 15, MonthModel.CHU_DAM, true);
        t1.setText(ten);
        TextView t2 = Ui.tv(this, 12, MonthModel.XAM2, false);
        t2.setText(phu);
        c.addView(t1);
        c.addView(t2);
        l.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        if (!chon) {
            TextView k = Ui.tv(this, 11, MonthModel.XAM, false);
            k.setText("Không đổi");
            l.addView(k);
        }
        if (bam != null) l.setOnClickListener(v -> bam.run());
        return l;
    }

    private LinearLayout dong(String trai, String phai, Runnable bam) {
        LinearLayout l = Ui.hang(this);
        l.setPadding(Ui.px(this, 14), Ui.px(this, 14), Ui.px(this, 14), Ui.px(this, 14));
        l.setBackground(Ui.bo(MonthModel.NEN2, 14, this));
        TextView t1 = Ui.tv(this, 14, MonthModel.CHU, false);
        t1.setText(trai);
        l.addView(t1, new LinearLayout.LayoutParams(0, -2, 1));
        TextView t2 = Ui.tv(this, 13, MonthModel.XAM2, false);
        t2.setText(phai + (bam != null ? "  ›" : ""));
        t2.setGravity(Gravity.END);
        l.addView(t2);
        if (bam != null) l.setOnClickListener(v -> bam.run());
        return l;
    }
}
