package vn.thaidisales.lich;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Tiện ích dựng giao diện tối dùng chung. */
final class Ui {
    private Ui() {}

    static int px(Activity a, float dp) { return Math.round(dp * a.getResources().getDisplayMetrics().density); }

    static GradientDrawable bo(int mau, float r, Activity a) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(mau);
        g.setCornerRadius(px(a, r));
        return g;
    }

    static TextView tv(Activity a, float sp, int mau, boolean dam) {
        TextView t = new TextView(a);
        t.setTextSize(sp);
        t.setTextColor(mau);
        if (dam) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static TextView nut(Activity a, String s, boolean chinh) {
        TextView b = tv(a, 14, chinh ? 0xFF0E1116 : MonthModel.CHU, true);
        b.setText(s);
        b.setGravity(Gravity.CENTER);
        b.setPadding(px(a, 16), 0, px(a, 16), 0);
        b.setMinHeight(px(a, 44));
        b.setBackground(bo(chinh ? MonthModel.XANH : MonthModel.NEN2, 22, a));
        return b;
    }

    static TextView muc(Activity a, String s) {
        TextView t = tv(a, 11, MonthModel.XAM, true);
        t.setText(s);
        t.setPadding(px(a, 4), px(a, 18), 0, px(a, 8));
        return t;
    }

    static EditText o(Activity a, String goiY) {
        EditText e = new EditText(a);
        e.setHint(goiY);
        e.setTextColor(MonthModel.CHU_DAM);
        e.setHintTextColor(MonthModel.XAM);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setBackground(bo(MonthModel.NEN2, 14, a));
        e.setPadding(px(a, 14), px(a, 12), px(a, 14), px(a, 12));
        e.setBackgroundTintList(null);
        return e;
    }

    static LinearLayout cot(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hang(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static ColorStateList mau(int c) { return ColorStateList.valueOf(c); }
}
