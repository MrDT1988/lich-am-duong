package vn.thaidisales.lich;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

/** Widget 1 khối: 2 đồng hồ (hoặc thời tiết) + lịch tháng + lịch họp. */
public class LichWidget extends AppWidgetProvider {
    static final String TRUOC = "vn.thaidisales.lich.TRUOC", SAU = "vn.thaidisales.lich.SAU",
            NUA_DEM = "vn.thaidisales.lich.NUA_DEM", LAM_MOI = "vn.thaidisales.lich.LAM_MOI";
    static final long TT_HAN = 30 * 60 * 1000L;

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        capNhat(c);
        if (Store.phaiLaThoiTiet(c) && System.currentTimeMillis() - Store.thoiTietLuc(c) > TT_HAN) {
            PendingResult pr = goAsync();
            new Thread(() -> { try { taiThoiTiet(c); capNhat(c); } finally { pr.finish(); } }).start();
        }
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (a == null) return;
        int lech = Store.sp(c).getInt("lech", 0);
        switch (a) {
            case TRUOC: lech--; break;
            case SAU: lech++; break;
            case LAM_MOI: break;
            case NUA_DEM: case Intent.ACTION_TIME_CHANGED: case Intent.ACTION_TIMEZONE_CHANGED:
            case Intent.ACTION_BOOT_COMPLETED: lech = 0; break;
            default: return;
        }
        Store.sp(c).edit().putInt("lech", lech).apply();
        capNhat(c);
    }

    /** Gọi từ app khi đổi cài đặt / lịch họp. */
    public static void lamMoi(Context c) {
        capNhat(c);
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, LichWidget.class));
        m.notifyAppWidgetViewDataChanged(ids, R.id.w_ds);
    }

    static void capNhat(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, LichWidget.class));
        if (ids.length == 0) return;
        LocalDate homNay = LocalDate.now(Store.VN);
        int lech = Store.sp(c).getInt("lech", 0);
        LocalDate thang = homNay.withDayOfMonth(1).plusMonths(lech);
        MonthModel mm = new MonthModel(thang.getYear(), thang.getMonthValue());
        Set<LocalDate> coHop = Store.ngayCoHop(c);

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_lich);

        // --- Khối trên
        v.setTextViewText(R.id.w_am, MonthModel.amNgan(homNay));
        boolean tt = Store.phaiLaThoiTiet(c);
        v.setViewVisibility(R.id.w_khoi_tz, tt ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.w_khoi_tt, tt ? View.VISIBLE : View.GONE);
        if (tt) {
            int[] w = Store.thoiTiet(c);
            boolean co = w[3] >= 0;
            v.setTextViewText(R.id.w_tt_noi, Store.CITY[Store.city(c)][0].toUpperCase());
            v.setTextViewText(R.id.w_tt_nhiet, co ? w[0] + "°" : "--°");
            v.setTextViewText(R.id.w_tt_mota, Store.moTa(w[3]));
            v.setTextViewText(R.id.w_tt_hilo, co ? "Cao " + w[1] + "° · Thấp " + w[2] + "°" : "Cần mạng để tải");
        } else {
            String[] z = Store.TZ[Store.tz(c)];
            v.setTextViewText(R.id.w_tz_nhan, z[0].toUpperCase());
            v.setString(R.id.w_gio_tz, "setTimeZone", z[2]);
            v.setString(R.id.w_ngay_tz, "setTimeZone", z[2]);
            v.setTextViewText(R.id.w_tz_chenh, z[1] + " · " + Store.chenh(z[2]));
        }

        // --- Lịch tháng
        v.setTextViewText(R.id.w_tieude, "Tháng " + mm.month + "  " + mm.year);
        for (int i = 0; i < 42; i++) {
            LocalDate d = mm.days[i];
            boolean today = d.equals(homNay);
            v.setTextViewText(Ids.O[i], mm.cell(i, today));
            v.setInt(Ids.O[i], "setBackgroundResource", today ? R.drawable.bg_today : 0);
            boolean cham = d.getMonthValue() == mm.month && coHop.contains(d);
            v.setViewVisibility(Ids.D[i], cham ? View.VISIBLE : View.GONE);
        }

        // --- Lịch họp
        List<Store.Hop> sap = Store.sapToi(c);
        v.setTextViewText(R.id.w_hop_dem, sap.isEmpty() ? "" : "· " + sap.size() + " việc sắp tới");
        Intent svc = new Intent(c, HopService.class);
        svc.setData(Uri.parse("lich://hop"));
        v.setRemoteAdapter(R.id.w_ds, svc);
        v.setEmptyView(R.id.w_ds, R.id.w_trong);
        Intent mau = new Intent(c, HopActivity.class);
        v.setPendingIntentTemplate(R.id.w_ds, PendingIntent.getActivity(c, 20, mau,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE));

        // --- Bấm
        v.setOnClickPendingIntent(R.id.w_truoc, bc(c, TRUOC, 1));
        v.setOnClickPendingIntent(R.id.w_sau, bc(c, SAU, 2));
        v.setOnClickPendingIntent(R.id.w_tieude, mo(c, MainActivity.class, 3));
        v.setOnClickPendingIntent(R.id.w_luoi, mo(c, MainActivity.class, 4));
        v.setOnClickPendingIntent(R.id.w_trai, mo(c, MainActivity.class, 5));
        v.setOnClickPendingIntent(R.id.w_phai, mo(c, CaiDatActivity.class, 6));
        v.setOnClickPendingIntent(R.id.w_them, mo(c, HopActivity.class, 7));
        v.setOnClickPendingIntent(R.id.w_trong, mo(c, HopActivity.class, 8));

        m.updateAppWidget(ids, v);
        henNuaDem(c);
    }

    static PendingIntent bc(Context c, String action, int code) {
        Intent i = new Intent(c, LichWidget.class).setAction(action);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent mo(Context c, Class<?> cls, int code) {
        Intent i = new Intent(c, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void henNuaDem(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        long t = LocalDate.now(Store.VN).plusDays(1).atStartOfDay(Store.VN).plusSeconds(5).toInstant().toEpochMilli();
        am.set(AlarmManager.RTC, t, bc(c, NUA_DEM, 9));
    }

    /** Tải thời tiết từ Open-Meteo (miễn phí, không cần khoá). Chạy ở luồng nền. */
    static void taiThoiTiet(Context c) {
        String[] city = Store.CITY[Store.city(c)];
        HttpURLConnection con = null;
        try {
            URL u = new URL("https://api.open-meteo.com/v1/forecast?latitude=" + city[1] + "&longitude=" + city[2]
                    + "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1");
            con = (HttpURLConnection) u.openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(10000);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            JSONObject o = new JSONObject(sb.toString());
            JSONObject cur = o.getJSONObject("current");
            JSONObject day = o.getJSONObject("daily");
            Store.luuThoiTiet(c,
                    (int) Math.round(cur.getDouble("temperature_2m")),
                    (int) Math.round(day.getJSONArray("temperature_2m_max").getDouble(0)),
                    (int) Math.round(day.getJSONArray("temperature_2m_min").getDouble(0)),
                    cur.getInt("weather_code"));
        } catch (Exception ignored) {
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
