package vn.thaidisales.lich;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Danh sách lịch họp cuộn được trong widget. */
public class HopService extends RemoteViewsService {
    static final String[] THU = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static class Factory implements RemoteViewsFactory {
        private final Context c;
        private List<Store.Hop> ds = new ArrayList<>();
        Factory(Context c) { this.c = c; }

        @Override public void onCreate() {}
        @Override public void onDataSetChanged() { ds = Store.sapToi(c); }
        @Override public void onDestroy() {}
        @Override public int getCount() { return ds.size(); }
        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int i) { return i < ds.size() ? ds.get(i).id : i; }
        @Override public boolean hasStableIds() { return true; }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.hop_item);
            if (i >= ds.size()) return v;
            Store.Hop h = ds.get(i);
            LocalDateTime g = h.gio();
            v.setTextViewText(R.id.i_gio, String.format("%02d:%02d", g.getHour(), g.getMinute()));
            v.setTextViewText(R.id.i_ngay, THU[g.getDayOfWeek().getValue() - 1] + " " + g.getDayOfMonth() + "/" + g.getMonthValue());
            v.setTextViewText(R.id.i_ten, h.ten.isEmpty() ? "(Chưa đặt tên)" : h.ten);
            v.setTextViewText(R.id.i_noi, h.noi);
            v.setOnClickFillInIntent(R.id.i_mo, new Intent().putExtra(HopActivity.ID, h.id).putExtra(HopActivity.VIEC, "mo"));
            v.setOnClickFillInIntent(R.id.i_xong, new Intent().putExtra(HopActivity.ID, h.id).putExtra(HopActivity.VIEC, "xong"));
            return v;
        }
    }
}
